import { ManagerLogin } from './ManagerLogin';

export default {
  name: 'ManagerLogin',
  element: ManagerLogin,
};

export const Default = () => <ManagerLogin />;
