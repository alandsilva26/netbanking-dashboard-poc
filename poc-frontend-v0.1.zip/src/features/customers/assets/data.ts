import { ICustomer } from 'features/customers';

export const data: ICustomer[] = [
  {
    customerId: '131231',
    firstName: 'Alan',
    lastName: 'Dsilva',
    email: 'alandsilva@gmail.com',
    dob: '26/04/2001',
  },
];
