import { Brand } from './Brand';

export default {
  name: 'Brand',
  element: Brand,
};

export const Default = () => <Brand />;
