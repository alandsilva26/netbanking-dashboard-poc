export interface DrawerProps {
  /* Width of drawer element */
  drawerWidth?: number;
}
