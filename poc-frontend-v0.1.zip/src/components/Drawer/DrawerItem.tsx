import { ListItem } from '@mui/material';

export const DrawerItem = () => {
  return (
    <>
      <ListItem>test</ListItem>
    </>
  );
};
