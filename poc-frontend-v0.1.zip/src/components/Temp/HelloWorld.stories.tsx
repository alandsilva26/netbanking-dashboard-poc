import { HelloWorld } from './HelloWorld';

export default {
  title: 'Hello World',
  component: HelloWorld,
};

export const Primary = () => <HelloWorld></HelloWorld>;
